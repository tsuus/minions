/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import dialogfx.DialogFX;
import javafx.scene.Node;
import javafx.scene.effect.SepiaTone;

/**
 *
 * @author ThinkPad
 */
public class DialogFactory {

    private DialogFX dialog;

    public DialogFactory(String title, String message) {
        dialog = new DialogFX();
        dialog.setTitleText(title);
        dialog.setMessage(message);

    }

    public void show(Node node) {
        dialog.showDialog();
        SepiaTone st = new SepiaTone();
        node.setEffect(st);

    }

    public void showwithouteffect() {
        dialog.showDialog();
    }

}
