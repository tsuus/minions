/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import jxl.*;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;

/**
 *
 * @author ThinkPad
 */
public class Excel_processer {

    public static void main(String[] args) throws Exception {
        ArrayList<String> al = new ArrayList<String>();
        al.add("Total Fee");
        al.add("Date");
        al.add("Subject");
        ArrayList<String> maillist = new ArrayList<String>();
        maillist.add("kate.wang@britishcouncil.org.cn");
        File f = new File("H:\\Desktop\\副本S704 Guiyang.xls");
        Excel_processer.fetchtable(f, al, maillist);
    }

    public static void writeHeader(WritableSheet sheet, ArrayList<String> header) throws Exception {
        WritableFont wf = new WritableFont(WritableFont.ARIAL, 13);
        WritableCellFormat cellFormat = new WritableCellFormat(wf);
        cellFormat.setBackground(Colour.GREY_25_PERCENT);
        cellFormat.setBorder(Border.ALL, BorderLineStyle.THIN);
        cellFormat.setAlignment(Alignment.CENTRE);

        for (int i = 0; i < header.size(); i++) {
            CellView cellView = new CellView();
            cellView.setSize(header.get(i).length() * 512 + 100); //设置自动大小  
            sheet.setColumnView(i, cellView);//根据内容自动设置列宽  
            sheet.addCell(new Label(i, 0, header.get(i), cellFormat));

        }

    }

    public static void pushRow(WritableSheet sheet, ArrayList<String> row, int rownum) throws Exception {

        for (int i = 0; i < row.size(); i++) {

            sheet.addCell(new Label(i, rownum, row.get(i)));
        }

    }

    public static void pushColumn(WritableSheet sheet, ArrayList<String> col, int colnum) throws Exception {

        for (int i = 0; i < col.size(); i++) {
            sheet.addCell(new Label(colnum, i, col.get(i)));
        }

    }

    public static ArrayList<String> getHeader(File filepath) throws Exception {
        WorkbookSettings wbSetting = new WorkbookSettings();
        wbSetting.setGCDisabled(true);
        wbSetting.setUseTemporaryFileDuringWrite(true);
        Workbook book = Workbook.getWorkbook(filepath, wbSetting);
        Sheet sheet = book.getSheet(0);

        int rsColumns = sheet.getColumns();
        ArrayList<String> header = new ArrayList<String>();

//获得第一个工作表对象
//得到第一列第一行的单元格
        for (int i = 0; i < rsColumns; i++) {
            if (sheet.getCell(i, 0).getContents() == null || sheet.getCell(i, 0).getContents().length() == 0) {
                Exception e = new Exception("EmptyHeaderException");
                throw e;
            } else {
                Cell cell1 = sheet.getCell(i, 0);
                header.add(cell1.getContents());
            }
        }
        book.close();
        return header;
    }

    /**
     *
     * @param filepath
     * @param header
     * @param oemaillist
     * @return
     * @throws Exception
     */
    public static ArrayList<ArrayList<String>> fetchtable(File filepath, ArrayList<String> header, ArrayList<String> oemaillist) throws Exception {
        WorkbookSettings wbSetting = new WorkbookSettings();
        wbSetting.setGCDisabled(true);
        wbSetting.setUseTemporaryFileDuringWrite(true);
        Workbook book = Workbook.getWorkbook(filepath, wbSetting);
        Sheet sheet = book.getSheet(0);

        int rsColumns = sheet.getColumns();
        int rsRows = sheet.getRows();
        ArrayList<String> oheader = new ArrayList<String>();
        ArrayList<Integer> locale = new ArrayList<Integer>();//记录原列的位置
        ArrayList<ArrayList<String>> newtable = new ArrayList<ArrayList<String>>();
//获得第一个工作表对象
//得到第一列第一行的单元格
        for (int i = 0; i < rsColumns; i++) {
            Cell cell1 = sheet.getCell(i, 0);
            oheader.add(cell1.getContents());
        }
        book.close();

        for (int j = 0; j < header.size(); j++) {//当前的header
            for (int k = 0; k < oheader.size(); k++) {//k为原来header中该参数的位置
                if (header.get(j).equals(oheader.get(k))) {
                    locale.add(k);
                }
            }
        }
        for (int row = 0; row < rsRows; row++) {
            ArrayList<String> rowelements = new ArrayList<String>();
            for (int k = 0; k < locale.size(); k++) {
                rowelements.add(Excel_processer.getRow(filepath, row).get(locale.get(k)));
            }
            rowelements.add(oemaillist.get(row));
            newtable.add(rowelements);
        }

        return newtable;

    }

    public static void validatefile(File filepath) throws Exception {
        WorkbookSettings wbSetting = new WorkbookSettings();
        wbSetting.setGCDisabled(true);
        wbSetting.setUseTemporaryFileDuringWrite(true);
        Workbook book = Workbook.getWorkbook(filepath, wbSetting);
        Sheet sheet = book.getSheet(0);

        int rsRow = sheet.getRows();
        int rsCol = sheet.getColumns();
        for (int i = 0; i < rsRow; i++) {
            for (int j = 0; j < rsCol; j++) {
                if (sheet.getCell(j, i).getContents() == null || sheet.getCell(j, i).getContents().length() == 0) {
                    Exception ex = new Exception("There are empty cell in the file in Column: " + String.valueOf(j) + "  Row: " + String.valueOf(i));
                    throw ex;
                }
            }
        }

    }

    public static ArrayList<String> getColumn(File filepath, int columnnum) throws Exception {
        WorkbookSettings wbSetting = new WorkbookSettings();
        wbSetting.setGCDisabled(true);
        wbSetting.setUseTemporaryFileDuringWrite(true);
        Workbook book = Workbook.getWorkbook(filepath, wbSetting);
        Sheet sheet = book.getSheet(0);

        int rsRow = sheet.getRows();
        ArrayList<String> column = new ArrayList<String>();

//获得第一个工作表对象
//得到第一列第一行的单元格
        for (int i = 0; i < rsRow; i++) {
            if (sheet.getCell(columnnum, i).getContents() == null || sheet.getCell(columnnum, i).getContents().length() == 0) {
                Exception ex = new Exception("EmptyColumnException");
                throw ex;
            } else {
                Cell cell1 = sheet.getCell(columnnum, i);
                column.add(cell1.getContents());
            }
        }
        book.close();

        return column;

    }

    public static ArrayList<String> getRow(File filepath, int rownum) throws Exception {
        WorkbookSettings wbSetting = new WorkbookSettings();
        wbSetting.setGCDisabled(true);
        wbSetting.setUseTemporaryFileDuringWrite(true);
        Workbook book = Workbook.getWorkbook(filepath, wbSetting);
        Sheet sheet = book.getSheet(0);
        int rsColumn = sheet.getColumns();
        ArrayList<String> row = new ArrayList<String>();
//获得第一个工作表对象
//得到第一列第一行的单元格
        for (int i = 0; i < rsColumn; i++) {
            if (sheet.getCell(i, rownum).getContents() == null || sheet.getCell(i, rownum).getContents().length() == 0) {
                Exception ex = new Exception("EmptyRowException");
                throw ex;
            } else {
                Cell cell1 = sheet.getCell(i, rownum);
                row.add(cell1.getContents());
            }
        }
        //System.out.println(row.toString());
        book.close();

        return row;

    }

    public static ArrayList removeDuplicate(ArrayList list) {
        Set set = new HashSet();
        ArrayList newList = new ArrayList();
        for (Iterator iter = list.iterator(); iter.hasNext();) {
            Object element = iter.next();
            if (set.add(element)) {
                newList.add(element);
            }
        }
        return newList;
    }

}
