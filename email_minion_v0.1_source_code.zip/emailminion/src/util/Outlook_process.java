/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.scene.control.MenuItem;

/**
 *
 * @author ThinkPad
 */
public class Outlook_process {

    public static void sendEmail(String recipient, String subject, String copyto, String htmlbody, ArrayList<String> attaches) throws FileNotFoundException, IOException {

        ActiveXComponent axOutlook = new ActiveXComponent("Outlook.Application");

        Dispatch mailItem = Dispatch.call(axOutlook, "CreateItem", 0).getDispatch();
        Dispatch inspector = Dispatch.get(mailItem, "GetInspector").getDispatch();
        Dispatch recipients = Dispatch.call(mailItem, "Recipients").getDispatch();
        Dispatch attachments = Dispatch.call(mailItem, "Attachments").getDispatch();
        Dispatch.call(recipients, "Add", recipient);
        if (attaches.size() > 0) {
            for (int i = 0; i < attaches.size(); i++) {

                Dispatch.call(attachments, "Add", attaches.get(i));
            }
        }
        Dispatch.put(mailItem, "Subject", subject);
        Dispatch.put(mailItem, "CC", copyto);

        Dispatch.put(mailItem, "HTMLBody", htmlbody);

        Dispatch.call(mailItem, "Display");
        Dispatch.call(mailItem, "Send");
    }

}
