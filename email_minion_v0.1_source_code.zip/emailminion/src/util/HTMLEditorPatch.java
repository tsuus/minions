/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import javafx.scene.Node;
import javafx.scene.web.HTMLEditor;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

/**
 *
 * @author ThinkPad
 */
public class HTMLEditorPatch {
    
 public static void insertHtml(HTMLEditor editor,String html){

Node webNode = editor.lookup(".web-view");
if (webNode instanceof WebView) {
     WebView webView = (WebView) webNode;
     WebEngine engine = webView.getEngine();
     engine.executeScript("insertTextAtCursor('"+html+"')"); // add js code here
}
 }

    

}
