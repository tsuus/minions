/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emailminion;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;

import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;

import javafx.scene.web.HTMLEditor;
import util.Excel_processer;

/**
 * FXML Controller class
 *
 * @author ThinkPad
 */
public class ReviewController implements Initializable {

    @FXML
    private TextField presubject;
    @FXML
    private TextField precopyto;
    @FXML
    private TextField prereceiver;
    @FXML
    private HTMLEditor prehtmleditor;
    @FXML
    private Pagination pagination;
    @FXML
    private MenuButton preattachment;

    /**
     * Initializes the controller class.
     *
     * @param url
     */
    String htmlagent;
    File excel;
    ArrayList<String> datarow;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
        presubject.setText(DataTransfer.subject);
        precopyto.setText(DataTransfer.copyto);

        excel = new File(DataTransfer.exfile);

        for (int i = 0; i < DataTransfer.attachement.length; i++) {
            MenuItem m=new MenuItem((String) (DataTransfer.attachement)[i]);
            preattachment.getItems().add(m);
        }

        choosepage(0);
        pagination.currentPageIndexProperty().addListener((obs, oldIndex, newIndex) -> choosepage(newIndex.intValue()));
        try {
            pagination.setPageCount(DataTransfer.recevier.size());
        } catch (Exception ex) {
            Logger.getLogger(ReviewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void choosepage(int newIndex) {
        int index = 0;

        try {
            if (DataTransfer.congregated) {
                index = Excel_processer.getColumn(excel, DataTransfer.email_colunmnum).indexOf(DataTransfer.recevier.get(newIndex));
            } else {
                index = newIndex + 1;
            }
            datarow = Excel_processer.getRow(excel, index);
            htmlagent = DataTransfer.content;
            for (int i = 0; i < Excel_processer.getHeader(excel).size(); i++) {
                String replaceAll = htmlagent.replace("《-" + Excel_processer.getHeader(excel).get(i) + "-》", datarow.get(i));
                htmlagent = replaceAll;
            }
            prehtmleditor.setHtmlText(htmlagent);
            prereceiver.setText(DataTransfer.recevier.get(newIndex));
            if (newIndex != 0 && DataTransfer.congregated && preattachment.getItems().size() > 0) {
                preattachment.getItems().remove(preattachment.getItems().size() - 1);
            }
            if (DataTransfer.congregated) {
                MenuItem element = new MenuItem("c:\\temp\\" + DataTransfer.filename + "_" + String.valueOf(newIndex + 1) + ".xls");
                element.setMnemonicParsing(false);
                preattachment.getItems().add(element);

            }
            // }
        } catch (Exception ex) {

            Logger.getLogger(ReviewController.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    @FXML
    private void qpreview(ActionEvent event) {
        ((Node) event.getSource()).getScene().getWindow().hide();
    }

}
