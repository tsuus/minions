/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emailminion;

import java.util.ArrayList;

/**
 *
 * @author ThinkPad
 */
public class DataTransfer {

    public static String subject;
    public static String copyto;
    public static ArrayList<String> recevier;
    public static String content;
    public static Object[] attachement;
    public static String exfile;
    public static int email_colunmnum;
    public static boolean congregated;
    public static String filename;

}
