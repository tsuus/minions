/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emailminion;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.web.HTMLEditor;
import util.Excel_processer;
import javafx.stage.FileChooser;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.effect.Glow;
import javafx.scene.input.InputMethodEvent;
import dialogfx.DialogFX;
import java.io.IOException;
import java.io.InputStream;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import util.DialogFactory;
import util.FileUtils;
import util.HTMLEditorPatch;
import util.Outlook_process;

/**
 * FXML Controller class
 *
 * @author ThinkPad
 */
public class EmailmimionController implements Initializable {

    @FXML
    private StackPane stackpane;
    @FXML
    private Pane mainpane;
    @FXML
    private ComboBox<String> columnname;
    @FXML
    private Button importall;
    @FXML
    private HTMLEditor templatefield;
    @FXML
    private ProgressBar progressbar;
    @FXML
    private Button attach;
    private File exfile;
    private File atfile;
    @FXML
    private MenuButton menufile;
    @FXML
    private ComboBox<String> attachmentlist;
    private ArrayList<String> attachmentarray = new ArrayList<String>();
    @FXML
    private TextField subject;
    @FXML
    private ComboBox<String> emailaddress;
    @FXML
    private ComboBox<String> collectorchoice;

    @FXML
    private TreeTableView treetable;

    @FXML
    private Button clearcolumn;
    private Glow glow;
    @FXML
    private Button send;
    @FXML
    private TextField copyto;
    @FXML
    private Button preview;
    @FXML
    private Button etable;
    @FXML
    private TextField etablename;
    private ArrayList<String> emaillist = null;
    private int email_columnnum;
    @FXML
    private CheckBox congregation;
    private String htmlstash;
    @FXML
    private Button clearattachment;
    @FXML
    private AnchorPane shroud;
    @FXML
    private ImageView loading;
    @FXML
    private Button addall;

    /**
     * Initializes the controller class.
     */
    @Override

    public void initialize(URL url, ResourceBundle rb) {
        Glow glow = new Glow();//threshold:界限,限度  
        glow.setLevel(0.0);
        copyto.textProperty().addListener((observable, oldValue, newValue) -> {
            send.disableProperty().set(true);
        });
        attachmentlist.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                Platform.runLater(() -> {
                    attachmentlist.getSelectionModel().clearSelection();
                });
            }
        });
        htmlstash = templatefield.getHtmlText();
        templatefield.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if (templatefield.getHtmlText() != htmlstash) {
                    send.disableProperty().set(true);
                    htmlstash = templatefield.getHtmlText();
                }
            }
        });
    }

    @FXML
    private void fileopen(ActionEvent event) {

        menufile.setEffect(glow);
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Excel", "*.xls", "*.csv")
        );
        exfile = fileChooser.showOpenDialog(stackpane.getScene().getWindow());
        if (exfile != null) {
            ObservableList<String> items;
            try {
                Excel_processer.validatefile(exfile);
                items = FXCollections.observableArrayList(Excel_processer.getHeader(exfile));
                //columnname.setVisibleRowCount(items.size() > 10 ? 10 : items.size());
                columnname.setItems(items);
                //emailaddress.setVisibleRowCount(items.size() > 10 ? 10 : items.size());
                emailaddress.setItems(items);
                //collectorchoice.setVisibleRowCount(items.size() > 10 ? 10 : items.size());
                collectorchoice.setItems(items);
                email_columnnum = emailaddress.getSelectionModel().getSelectedIndex();
                send.disableProperty().set(true);
                templatefield.setHtmlText("<html dir=\"ltr\"><head></head><body contenteditable=\"true\"><script>function insertTextAtCursor(text) {    var sel, range, html;    if (window.getSelection) {        sel = window.getSelection();        if (sel.getRangeAt && sel.rangeCount) {            range = sel.getRangeAt(0);            range.deleteContents();            range.insertNode( document.createTextNode(text) );        }    } else if (document.selection && document.selection.createRange) {        document.selection.createRange().text = text;    }}</script></body></html>");
            } catch (Exception ex) {
                if (ex.getMessage() == "EmptyHeaderException") {
                    DialogFactory df = new DialogFactory("Warning", "There are empty headers!Please check!");
                    df.show(menufile);
                } else if (ex.getMessage().startsWith("There are empty cell in the file in")) {
                    DialogFactory df = new DialogFactory("Warning", ex.getMessage());
                    df.show(menufile);
                } else {
                    Logger.getLogger(EmailmimionController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
    }

    @FXML
    private void insertsymbol(ActionEvent event) {
        String t1 = columnname.getSelectionModel().getSelectedItem();
        if (t1 != null) {
            templatefield.requestFocus();
            HTMLEditorPatch.insertHtml(templatefield, "《-" + t1 + "-》");
            columnname.getSelectionModel().clearSelection();
            send.disableProperty().set(true);
        }

    }

    @FXML
    private void inputed(InputMethodEvent event) {
        templatefield.setEffect(glow);
    }

    @FXML
    private void importall(ActionEvent event) {

        ObservableList<String> olist = columnname.getItems();

        for (int i = 0; i < olist.size(); i++) {
            HTMLEditorPatch.insertHtml(templatefield, "《-" + olist.get(i) + "-》");

        }
    }

    @FXML
    private void collect(ActionEvent keyevent) {
        String header = collectorchoice.getSelectionModel().getSelectedItem();
        TreeTableColumn<String, String> column = new TreeTableColumn<>(header);
        column.setPrefWidth(60);
        treetable.getColumns().add(column);
        send.disableProperty().set(true);
    }

    @FXML
    private void addallcolumn(ActionEvent event) {

        try {
            ArrayList<String> email_column = Excel_processer.getHeader(exfile);

            for (int i = 0; i < email_column.size() - 1; i++) {
                TreeTableColumn<String, String> column = new TreeTableColumn<>(email_column.get(i));
                column.setPrefWidth(60);
                treetable.getColumns().add(column);
                send.disableProperty().set(true);
            }
        } catch (Exception ex) {
            Logger.getLogger(EmailmimionController.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("collect all error");
        }

    }

    @FXML
    private void chooseaddress(ActionEvent event) {
        emailaddress.setEffect(glow);
        email_columnnum = emailaddress.getSelectionModel().getSelectedIndex();
        send.disableProperty().set(true);
    }

    @FXML
    private void clearheader(ActionEvent event) {
        treetable.getColumns().clear();
        etablename.setDisable(false);
        send.disableProperty().set(true);
    }

    @FXML
    private void subjectinsert(ActionEvent event) {
        subject.setEffect(glow);
    }

    @FXML
    private void attachfiles(ActionEvent event) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Document", "*.exe", "*.xls", "*.xlsx", "*.csv", "*.doc", "*.docx", "*.ppt", "*.pdf", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        atfile = fileChooser.showOpenDialog(stackpane.getScene().getWindow());
        if (atfile != null) {
            if (atfile.length() > 10 * 1024 * 1024) {
                DialogFX dialog = new DialogFX();
                dialog.setTitleText("Warning");
                dialog.setMessage("This file is larger than 10MB!" + String.valueOf(atfile.length() / 1024 / 1204));
                dialog.showDialog();
            } else {
                String filename = atfile.getPath();
                attachmentlist.getItems().add(filename);
                send.disableProperty().set(true);

            }
        }

        attachmentarray = new ArrayList<String>();
        for (int k = 0; k < attachmentlist.getItems().size(); k++) {
            attachmentarray.add(attachmentlist.getItems().get(k));
        }
    }

    private boolean resetRef() {
        exfile = null;
        attachmentlist.getItems().clear();
        send.disableProperty().set(true);
        treetable.getColumns().clear();
        send.disableProperty().set(true);
        congregation.setSelected(false);
        collectorchoice.setDisable(true);
        clearcolumn.setDisable(true);
        etablename.setDisable(true);
        etable.setDisable(true);
        addall.setDisable(true);
        emailaddress.getSelectionModel().clearSelection();
        collectorchoice.getSelectionModel().clearSelection();
        subject.clear();
        columnname.getItems().clear();
        emailaddress.getItems().clear();
        templatefield.getHtmlText().replace(htmlstash, "<html><head></head><body>");
        File temp = new File("c:\\temp\\");
        if (!temp.exists()) {
            temp.mkdir();
        } else {
            FileUtils.deleteFile(temp);
            temp.mkdir();
        }
        return false;

    }

    private boolean validation() {
        if (exfile == null) {
            DialogFactory df = new DialogFactory("Warning", "You haven't uploaded any Excel Source File Yet!");
            df.show(menufile);
        } else if (emailaddress.getSelectionModel().getSelectedIndex() == -1) {
            DialogFactory df = new DialogFactory("Warning", "You haven't chosen which column is email-address Yet!");
            df.show(emailaddress);
        } else if (templatefield.getHtmlText().equals("<html dir=\"ltr\"><head></head><body contenteditable=\"true\"><script>function insertTextAtCursor(text) {    var sel, range, html;    if (window.getSelection) {        sel = window.getSelection();        if (sel.getRangeAt && sel.rangeCount) {            range = sel.getRangeAt(0);            range.deleteContents();            range.insertNode( document.createTextNode(text) );        }    } else if (document.selection && document.selection.createRange) {        document.selection.createRange().text = text;    }}</script></body></html>"
        )) {
            DialogFactory df = new DialogFactory("Warning", "You haven't written anything Yet!");
            df.show(templatefield);

        } else if (subject.getText().length() == 0) {
            DialogFactory df = new DialogFactory("Warning", "You haven't written the Subject Yet!");
            df.show(subject);
        } else if (congregation.isSelected() && emaillist == null) {
            DialogFactory df = new DialogFactory("Warning", "You have to add congregation attachment before preview!");
            df.show(etable);
        } else {
            return true;
        }
        return false;
    }

    @FXML
    private void sendemail(ActionEvent event) {

        if (validation() != false) {
            //the columnnumber of the email column
            Service service = null;

            try {
                ArrayList<String> email_column = Excel_processer.getColumn(exfile, email_columnnum);

                //get the entire email column
                String htmlbody = templatefield.getHtmlText();
                //get the htmlbody

                if (!congregation.isSelected()) {

                    service = new Service() {
                        @Override
                        protected Task createTask() {
                            return new Task() {
                                String htmlagent;

                                @Override
                                protected Object call() throws Exception {

                                    for (int j = 1; j < DataTransfer.recevier.size() + 1; j++) {
                                        ArrayList<String> datarow = Excel_processer.getRow(exfile, j);

                                        htmlagent = htmlbody;
                                        for (int i = 0; i < columnname.getItems().size(); i++) {
                                            String replaceAll = htmlagent.replace("《-" + columnname.getItems().get(i) + "-》", datarow.get(i));//substitute symbol
                                            htmlagent = replaceAll;
                                        }
                                        Outlook_process.sendEmail((String) email_column.get(j), subject.getText(), copyto.getText(), htmlagent, attachmentarray);
                                        updateProgress(j, (email_column.size() - 1));
                                    }

                                    return null;
                                }
                            };
                        }

                        @Override

                        protected void failed() {

                            DialogFactory df = new DialogFactory("Warning", "Unable to finish the sending task. Please check the email address.");
                            shroudcontrol(false);
                            progressbar.progressProperty().unbind();
                            progressbar.progressProperty().set(0.0);

                        }

                        @Override

                        protected void succeeded() {
                            DialogFX dialog = new DialogFX();
                            dialog.setTitleText(
                                    "Successful!");
                            dialog.setMessage(
                                    "You have sent " + String.valueOf(DataTransfer.recevier.size()) + " emails!");
                            dialog.showDialog();
                            shroudcontrol(false);
                            resetRef();
                            attachmentarray = new ArrayList<String>();
                        }

                    };

                    progressbar.progressProperty().bind(service.progressProperty());
                    shroudcontrol(true);
                    service.start();
                } else {

                    ObservableList<MenuItem> temp = null;
                    service = new Service() {
                        @Override
                        protected Task createTask() {
                            Task task = new Task() {
                                String htmlagent;

                                @Override
                                protected Object call() throws Exception {

                                    for (int newIndex = 1; newIndex < DataTransfer.recevier.size() + 1; newIndex++) {
                                        String htmlagent;
                                        int index = 0;
                                        ArrayList<String> datarow = null;
                                        index = Excel_processer.getColumn(exfile, DataTransfer.email_colunmnum).indexOf(DataTransfer.recevier.get(newIndex - 1));
                                        datarow = Excel_processer.getRow(exfile, index);
                                        htmlagent = DataTransfer.content;
                                        for (int i = 0; i < Excel_processer.getHeader(exfile).size(); i++) {
                                            String replaceAll = htmlagent.replace("《-" + Excel_processer.getHeader(exfile).get(i) + "-》", datarow.get(i));
                                            htmlagent = replaceAll;
                                        }
                                        if (newIndex != 1) {
                                            attachmentarray.remove(attachmentarray.size() - 1);
                                        }
                                        attachmentarray.add("c:\\temp\\" + etablename.getText().trim() + "_" + String.valueOf(newIndex) + ".xls");
                                        Outlook_process.sendEmail(DataTransfer.recevier.get(newIndex - 1), subject.getText(), copyto.getText(), htmlagent, attachmentarray);
                                        updateProgress(newIndex, DataTransfer.recevier.size());
                                    }

                                    return null;
                                }
                            };
                            return task;
                        }

                        @Override
                        protected void failed() {
                            DialogFactory df = new DialogFactory("Warning", "Unable to finish the sending task. Please check the email address.");
                            shroudcontrol(false);
                            progressbar.progressProperty().unbind();
                            progressbar.progressProperty().set(0.0);

                        }

                        @Override

                        protected void succeeded() {
                            DialogFX dialog = new DialogFX();
                            dialog.setTitleText(
                                    "Successful!");
                            dialog.setMessage(
                                    "You have sent " + String.valueOf(DataTransfer.recevier.size()) + " emails!");
                            dialog.showDialog();
                            shroudcontrol(false);
                            resetRef();
                            attachmentarray = new ArrayList<String>();
                        }

                    };
                    progressbar.progressProperty().bind(service.progressProperty());
                    shroudcontrol(true);
                    service.start();

                }

            } catch (Exception e) {
                Logger.getLogger(EmailmimionController.class
                        .getName()).log(Level.SEVERE, null, e);
            }
            send.disableProperty().set(true);
        }//

    }

    @FXML
    private void previewwindow(ActionEvent event) throws IOException {
        if (validation() == true) {
            DataTransfer.subject = subject.getText();
            DataTransfer.copyto = copyto.getText();
            DataTransfer.attachement = attachmentlist.getItems().toArray().clone();
            DataTransfer.content = templatefield.getHtmlText();
            email_columnnum = emailaddress.getSelectionModel().getSelectedIndex();
            DataTransfer.exfile = exfile.toString();
            DataTransfer.email_colunmnum = email_columnnum;
            try {
                ArrayList<String> temp = Excel_processer.getColumn(exfile, email_columnnum);
                temp.remove(0);
                if (!congregation.isSelected()) {
                    DataTransfer.recevier = temp;
                    DataTransfer.congregated = false;
                } else {

                    DataTransfer.recevier = emaillist;
                    DataTransfer.congregated = true;
                    DataTransfer.filename = etablename.getText().trim();
                }

                Stage secondstage = new Stage();
                FXMLLoader fxmlLoader = new FXMLLoader();
                Pane popUp;
                fxmlLoader.setLocation(getClass().getResource("review.fxml"));
                popUp = fxmlLoader.load();
                Scene secondScene = new Scene(popUp, 600, 500);
                secondstage.setScene(secondScene);
                Image image = new Image("/minion.jpg", 400, 400, true, true);
                secondstage.getIcons().add(image);
                secondstage.show();
                send.setDisable(false);

            } catch (Exception e) {
                if (e.getMessage() == "EmptyColumnException") {
                    DialogFactory df = new DialogFactory("Warning", "Please check your Excel file and make sure that there are no empty cells!");
                    df.show(menufile);

                } else {
                    Logger.getLogger(EmailmimionController.class
                            .getName()).log(Level.SEVERE, null, e);
                }
            }

        }

    }

    @FXML
    private void attachtable(ActionEvent event) throws Exception {
        File temp = new File("c:\\temp\\");
        if (!temp.exists()) {
            temp.mkdir();
        } else {
            FileUtils.deleteFile(temp);
            temp.mkdir();
        }

        int email_chose = emailaddress.getSelectionModel().getSelectedIndex();
        if (email_chose != -1 && etablename.getText().trim().length() != 0 && treetable.getColumns().size() != 0) {
            Service service = new Service() {
                @Override
                protected Task createTask() {
                    return new Task<Void>() {// prograssbar
                        File file;
                        ArrayList<String> header = new ArrayList<String>();
                        TreeTableColumn<String, String> column;

                        @Override
                        protected Void call() throws Exception {
                            for (int i = 0; i < treetable.getColumns().size(); i++) {
                                column = (TreeTableColumn<String, String>) treetable.getColumns().get(i);
                                header.add(column.getText());
                            }
                            try {
                                ArrayList<String> oemaillist = Excel_processer.getColumn(exfile, email_chose);
                                emaillist = Excel_processer.removeDuplicate(oemaillist);

                                for (int j = 1; j < emaillist.size(); j++) {//不同的邮箱数
                                    file = new File("c:\\temp\\", etablename.getText().trim() + "_" + String.valueOf(j) + ".xls");
                                    WorkbookSettings wbSetting = new WorkbookSettings();
                                    wbSetting.setGCDisabled(true);
                                    wbSetting.setUseTemporaryFileDuringWrite(true);
                                    WritableWorkbook book = Workbook.createWorkbook(file, wbSetting);
                                    WritableSheet sheet = book.createSheet("Sheet1", 0);
                                    Excel_processer.writeHeader(sheet, header);//write header
                                    ArrayList<ArrayList<String>> newtable = Excel_processer.fetchtable(exfile, header, oemaillist);
                                    int newrow = 1;
                                    for (int row = 1; row < newtable.size(); row++) {
                                        if (newtable.get(row).contains(emaillist.get(j))) {
                                            newtable.get(row).remove(header.size());
                                            Excel_processer.pushRow(sheet, newtable.get(row), newrow++);
                                        }
                                    }
                                    book.write();
                                    book.close();
                                    updateProgress(j, emaillist.size() - 1);
                                }

                                emaillist.remove(0);

                            } catch (Exception e) {
                                Logger.getLogger(EmailmimionController.class
                                        .getName()).log(Level.SEVERE, null, e);
                            }

                            return null;
                        }
                    };// prograssbar
                }

                @Override
                protected void succeeded() {
                    DialogFactory df = new DialogFactory("Info", "The Attachments have been produced");
                    df.showwithouteffect();
                    shroudcontrol(false);

                }
            };

            progressbar.progressProperty().bind(service.progressProperty());
            shroudcontrol(true);
            service.start();
            etablename.setDisable(true);

        } else if (email_chose == -1) {
            DialogFactory df = new DialogFactory("Warning", "You haven't told me which column is the email column yet!");
            df.show(emailaddress);
        } else if (etablename.getText().trim().length() == 0) {
            DialogFactory df = new DialogFactory("Warning", "You haven't assigned a filename yet");
            df.show(etablename);
        } else if (treetable.getColumns().size() == 0) {
            DialogFactory df = new DialogFactory("Warning", "You haven't drawn any column yet!");
            df.show(treetable);
        }
        send.disableProperty().set(true);
    }

    @FXML
    private void congregate(ActionEvent event) {
        if (congregation.isSelected()) {
            collectorchoice.setDisable(false);
            clearcolumn.setDisable(false);
            etablename.setDisable(false);
            etable.setDisable(false);
            addall.setDisable(false);
        } else {
            collectorchoice.setDisable(true);
            clearcolumn.setDisable(true);
            etablename.setDisable(true);
            etable.setDisable(true);
            addall.setDisable(true);

        }
        send.disableProperty().set(true);
    }

    @FXML
    private void clearattachedfiles(ActionEvent event) {
        attachmentlist.getItems().clear();
        send.disableProperty().set(true);
    }

    private void shroudcontrol(boolean sw) {
        if (sw) {//shroud all the controls
            shroud.disableProperty().set(false);
            shroud.opacityProperty().set(.50);
            loading.visibleProperty().set(true);
        } else {//stop shrouding all the controls
            shroud.disableProperty().set(true);
            shroud.opacityProperty().set(0);
            loading.visibleProperty().set(false);

        }
    }

}
